﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class PatrolC : MonoBehaviour {
	public Transform target1;
	public Transform target2;
	public float speed;
	public float spinspeed;
	private Transform currenttarget;
	public static int Aggro = 0;
	private float AngerTime = 0;

	// Use this for initialization
	void Start () {
		currenttarget = target1;
	}
	
	// Update is called once per frame
	void Update () {
		if (Aggro == 0) {
			var step = speed * Time.deltaTime;

			transform.position = Vector3.MoveTowards (transform.position, currenttarget.position, step);

			if (transform.position == currenttarget.transform.position) {

				if (currenttarget == target1) {

					currenttarget = target2;
					this.transform.LookAt (target2);
				} else {

					currenttarget = target1;
					this.transform.LookAt (target1);
				}
			}


			//everything below is spaghetti code to deal with the robot attacking and I'm sorry(I'm not)
		}
		if (Aggro == 1) {
			Debug.Log ("I HAVE BEEN ANGERED");
			AngerTime = AngerTime + 1 * Time.deltaTime;
			transform.Rotate (Vector3.up, 40 * Time.deltaTime);
		}

		if(AngerTime >= 100){
			Laser.fire = 1;
		}
		
	}

}
