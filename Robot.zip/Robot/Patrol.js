﻿#pragma strict

static var currentTarget : Transform;
var targetOne : Transform;
var targetTwo : Transform;

static var speed = 1;

function Start () {

	currentTarget = targetOne;
}

function Update () {

	if(transform.position == currentTarget.transform.position){

		Switch ();
	}

    var step = speed * Time.deltaTime;

	transform.position = Vector3.MoveTowards(transform.position, currentTarget.position, step);
}


function Switch () {

	if(currentTarget == targetOne){

		currentTarget = targetTwo;
		this.transform.LookAt(targetTwo);
	}

	else{

		currentTarget = targetOne;
		this.transform.LookAt(targetOne);
	}
}