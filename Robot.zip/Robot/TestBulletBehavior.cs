﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestBulletBehavior : MonoBehaviour {
	public GameObject Player;
	public float speed;
	// Use this for initialization
	void Start () {
		
	}

	void OnCollisionEnter(Collision a){
		if (a.gameObject.tag.Equals ("Player") == true) {
			PatrolC.Aggro = 1;
			Destroy (this.gameObject);
		} else {
			Destroy (this.gameObject);
		}
	}
	// Update is called once per frame
	void Update () {
		Player = GameObject.Find("FPSController");
		float step = speed * Time.deltaTime;
		transform.position = Vector3.MoveTowards (transform.position, Player.transform.position, step);
	}
}
