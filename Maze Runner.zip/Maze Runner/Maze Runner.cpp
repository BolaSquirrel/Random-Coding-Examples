#include <iostream.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>
#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>

// Programmer: Weston Sapusek
// Based off of the Matrix example by Mrs. Cunningham


void printmap(char map[23][50]);
void victory();
int hp=30; //If you are feeling brave, set this number to 22.
int CH=0;  //Creature Health
int score=0;
int moves=0;
main()
{
int i=1;
mciSendString("play Maze_music.mp3",NULL,0,NULL); //http://www.youtube.com/watch?v=UBVoONryE3s
     char ch;
     int r=1;
     int c=2;
     char map[22][50]={
                     {'#',' ',' ',' ','#','#','#','#','#','#','#','#',' ',' ',' ',' ',' ',' ',' ',' ','#','#','#','#',' ','#','#','#','#',' ','#','#',' ',' ','1','#','#','#',' ',' ',' ',' ',' ','1','1','1','1','1','1','#'},
                     {'#',' ','X',' ',' ','1',' ','3',' ',' ',' ','#',' ','#','#',' ','#','#','#',' ','#',' ',' ',' ',' ',' ',' ',' ','1',' ','#','#',' ','#',' ',' ',' ','#',' ','#','#','#',' ','#','#','#','#','#','#','#'},
                     {'#',' ',' ',' ','#','#','#','#','#','#','2','#',' ','#',' ','#','#','8','#',' ','#',' ','#','#','#','#',' ','#','#',' ','#','#',' ','#','#','#','#','#',' ','#',' ',' ',' ','#',' ',' ',' ',' ',' ','#'},
                     {'#','#',' ','#','#',' ',' ','1',' ','#',' ','#','2',' ',' ','#','#',' ',' ',' ',' ',' ',' ',' ',' ','#',' ','#','#',' ','#','#','1',' ',' ','4',' ',' ',' ','#','#','#',' ','#',' ','#','#','#',' ','#'},
                     {'#','#',' ','#','#','#','#','#',' ',' ',' ','#',' ','#',' ',' ',' ',' ','#','#',' ','#','#','#',' ','#',' ','#',' ',' ',' ','#',' ','#','#','#','#','#',' ','#','#',' ',' ','#',' ','#','#','#',' ','#'},
                     {'#',' ',' ','#','#',' ','#','#',' ','#','#','#','#','#',' ','#','#',' ','#','#',' ','#',' ','#','1','#',' ','#','#','#','#','#',' ','#','#','#',' ','#',' ','#','#',' ','#','#',' ',' ',' ','#',' ','#'},
                     {'#',' ','#','#','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#','#',' ','#','#',' ','#',' ','#',' ','#',' ',' ',' ',' ',' ','6',' ',' ',' ',' ',' ','#',' ','#','#',' ','#',' ','#','#','4','#',' ','#'},
                     {'#',' ','#',' ','#','#','#','#','#','#','#','#','#','#',' ','#','#',' ','#','#',' ','#','2',' ',' ','#','#','#','#','#','#','#',' ','#','#','#',' ','#',' ','#','#',' ','#',' ','#','#',' ','#',' ','#'},
                     {'#','1','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#','#',' ','#',' ','#','#','#',' ',' ',' ',' ','#','#',' ','#',' ','#',' ','#',' ','#','#',' ','5',' ',' ',' ',' ','#',' ','#'},
                     {'#',' ','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',' ','#',' ','#',' ','#','#','#','#','#','1','#',' ',' ',' ','#',' ',' ',' ','#',' ','#','#','#','#','#',' ','#'},
                     {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#',' ','#','#',' ',' ',' ',' ',' ',' ','#',' ','#',' ','#',' ','#',' ',' ',' ',' ',' ','#','1','#',' ','#','#','#',' ','#',' ','#',' ',' ',' ',' ',' ','#'},
                     {'#','#','#','#',' ','#','#','#','#','#',' ','#',' ',' ',' ',' ','#',' ','#','#',' ','#',' ','#',' ',' ',' ','#',' ','#','#',' ','#',' ',' ','#',' ',' ',' ','#',' ','#',' ','#',' ','#','#','#','#','#'},
                     {'#','#',' ',' ',' ','#','#','1','#','#',' ','#','#','#',' ','#',' ',' ','#','#','4','#',' ','#',' ','#','#','#',' ','#',' ',' ','#','#',' ','#','#','#','#','#',' ','#',' ','#',' ',' ',' ',' ',' ','#'},
                     {'#',' ',' ','#','#','#','1','1','#','#','1','#',' ',' ',' ','#',' ','#',' ','#',' ','#',' ','#',' ','#',' ','#','2','#','#',' ','#','#',' ',' ',' ',' ',' ','#',' ',' ',' ',' ','#','#',' ','#',' ','#'},
                     {'#','#','6',' ','2',' ','1','#','#','#',' ','#','1','#',' ','#',' ','#','2','#',' ','#',' ','#',' ','#',' ','#',' ','#','#',' ',' ','#','#','#',' ','#',' ','#',' ','#','#','#','#','#',' ','#',' ','#'},
                     {'#','#','#','#','#','#','#','#','#','#',' ','#',' ','#',' ','#',' ','#',' ','#',' ','#',' ','#','2','#','2','#',' ',' ',' ','#',' ','#','#','#','9','#',' ','#','9','#',' ',' ',' ','#','#','#',' ','#'},
                     {'#',' ',' ',' ',' ','1','#',' ',' ',' ',' ','#','#','#','3','#',' ','#',' ','#',' ','#',' ','#',' ','#',' ','#','#','#',' ','#','#',' ','1',' ','#','#',' ','#','#',' ',' ','#',' ',' ',' ',' ',' ','#'},
                     {'#',' ','#','#','#','#','#','#','#',' ','#','#',' ','#',' ','#',' ','#',' ','#',' ','#','2','#',' ',' ',' ',' ',' ','#',' ','#','#',' ','#',' ',' ',' ','1','#','#',' ','#','#',' ','#','#','#','#','#'},
                     {'#',' ',' ',' ',' ',' ',' ','5',' ',' ','#','#',' ',' ',' ','#','2','#',' ',' ',' ','#',' ','#','#','#','#','#','#','#','1','#','#',' ','#','#','#','#','#','#','#',' ','#','#',' ','#',' ',' ',' ','#'},
                     {'#',' ','#','#','#','#','#','#','#','#','#','#','#','#',' ','#',' ','#','#','#','#','#',' ',' ','4',' ',' ',' ',' ',' ',' ','#','#',' ','5',' ',' ',' ',' ',' ',' ',' ','#','#',' ','9',' ','G',' ','#'},
                     {'#',' ',' ',' ',' ',' ',' ',' ',' ','2',' ',' ',' ',' ',' ','#',' ',' ',' ',' ',' ','2',' ','#','#','#','#','#','#','#',' ',' ',' ','#','#','#','#','#','#','#','#','#','#','#','#','#',' ',' ',' ','#'},
                     {'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'},
                    };

     cout << "Move using the arrow keys." << endl;
     cout << "Navigate the X to the goal!" << endl;
     cout << "Use the w, a, s, and d keys to swing your sword!" << endl;
     cout << "Use your sword to defeat the creatures!" << endl;
     cout << "Be cautious, some creatures will fight back. " << endl;
     cout << "Weak creatures will not fight back." << endl;
     cout << "The numbers represent how much health a creature has." << endl;
     cout << "Navigate around the maze of blocks!" << endl;
     cout << "Get to the (G)oal to win the game!" << endl;
     cout << "Good luck! Press any key when ready to start." << endl;
     getch();
     clrscr();
     printmap(map);
     do
     {
     ch = getch();
     switch((int)ch)
     {
      case 75:        // left
      if(map[r][c-1]=='G') //Checks for win condition first
         {
         i--;
         victory();
         }
      if(map[r][c-1]==' ') //Checks to make sure space is empty
      	{
      	map[r][c]=' ';
         map[r][c-1]='X';
         c--;
         moves++;
         }
         break;
      case 72:       // up
          if(map[r-1][c]=='G')
         {
         i--;
         victory();
         }
         if(map[r-1][c]==' ')
      	{
      	map[r][c]=' ';
         map[r-1][c]='X';
         r--;
         moves++;
         }
         break;
      case 80:      // down
         if(map[r+1][c]=='G')
         {
         i--;
         victory();
         }
         if(map[r+1][c]==' ')
      	{
        	map[r][c]=' ';
         map[r+1][c]='X';
         r++;
         moves++;
         }

         break;
      case 77:     // right
         if(map[r][c+1]=='G')
         {
         i--;
         victory();
         }
         if(map[r][c+1]==' ')
      	{
         map[r][c]=' ';
         map[r][c+1]='X';
         c++;
         moves++;
         }
         break;
      default:
      break;

	case 97: //a key
      if(map[r][c-1]=='1') //checks to see if creature has 1 health
      {
      map[r][c-1]=' '; //kills it instantly, no damage done to you.
      score=score+50;
      }
      if(map[r][c-1]!='#')
      	{
         if(map[r][c-1]!=' ') //checks to see if the space is something other than a '#', a ' ' or a 'G', which would mean it is a creature.
         	{
            if(map[r][c-1]!='G')
            	{
               CH=map[r][c-1];
               CH=CH-1;
               map[r][c-1]=CH;
               hp--;          //damages the creature then you
               score=score+10; //adds score whenever you hit a creature
               }
               }
               }
               break;

   	case 100: //d key
      if(map[r][c+1]=='1')
      {
      map[r][c+1]=' ';
      }
      if(map[r][c+1]!='#')
      	{
         if(map[r][c+1]!=' ')
         	{
            if(map[r][c+1]!='G')
            	{
               CH=map[r][c+1];
               CH=CH-1;
               map[r][c+1]=CH;
               hp--;
               score=score+10;
               }
               }
               }
               break;

      case 119: //w key
      if(map[r-1][c]=='1')
      {
      map[r-1][c]=' ';
      }
      if(map[r-1][c]!='#')
      	{
         if(map[r-1][c]!=' ')
         	{
            if(map[r-1][c]!='G')
            	{
               CH=map[r-1][c];
               CH=CH-1;
               map[r-1][c]=CH;
               hp--;
               score=score+10;
               }
               }
               }
               break;

      case 115: //s key
      if(map[r+1][c]=='1')
      {
      map[r+1][c]=' ';
      }
      if(map[r+1][c]!='#')
      	{
         if(map[r+1][c]!=' ')
         	{
            if(map[r+1][c]!='G')
            	{
               CH=map[r+1][c];
               CH=CH-1;
               map[r+1][c]=CH;
               hp--;
               score=score+10;
               }
               }
               }
               break;
               }

if(hp==0)
{
clrscr();
mciSendString("stop Maze_music.mp3",NULL,0,NULL);
mciSendString("play Rickroll.mp3",NULL,0,NULL); //this song is a Rick Roll. :P
cout << "You have been defeated." << endl;
getch();
cout << "Now you will be Rickrolled!" << endl;
getch();
cout << "Final score:" << score << endl;
getch();
i--;
}

if(i==1)
{
clrscr();
printmap(map);
cout << "health: " << hp << endl;
}


     }
while(i==1);
     return 0;
}


void printmap(char map[22][50])
{
   for(int r=0;r<=21;r++)
   {
      for(int c=0;c<=49;c++)
      {
         cout << map[r][c];
      }
      cout << endl;
   }
   cout << endl;
}

void victory()
{
clrscr();
mciSendString("stop Maze_music.mp3",NULL,0,NULL);
mciSendString("play Victory.mp3",NULL,0,NULL);
score=score+500;
cout << "You win! Congratulations!" << endl;
getch();
cout << "Thanks for playing!" << endl;
getch();
if(hp==1) //score bonus for 1 health
{
cout << "You barely survived!" << endl;
getch();
cout << "You really put your all into this adventure." << endl;
getch();
cout << "You are awarded 200 additional points." << endl;
getch();
score=score+500;
}
if(moves<=150) //score bonus for taking less than 150 moves to win
{
cout << "You were very quick about all this." << endl;
cout << "You are awarded 100 extra points." << endl;
score=score+100;
}
cout << "Final score: " << score << endl;
getch();
cout << "Total moves: " << moves << endl;
getch();
}
