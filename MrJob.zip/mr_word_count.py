"""
Taken from
https://pythonhosted.org/mrjob/guides/quickstart.html#writing-your-first-job,
last access 11/13/2017
"""

# To test locally, from Terminal:
#    python mr_word_count.py --conf-path=mrjob.conf gutenberg.txt > counts.txt

# To run on AWS Elastic Map Reduce (EMR), from Terminal:
# You can first run a cluster that can be reused via:
#    mrjob create-cluster --conf-path=mrjob.conf
#    Watch for the cluster id starting with j-
#    Next run your job on the cluster using:
#        python mr_word_count.py -r emr --cluster-id=j-<CLUSTER ID> --conf-path=mrjob.conf gutenberg.txt > counts.txt
# When finished with the cluster you created, you can terminate it using:
#    mrjob terminate-cluster --conf-path=mrjob.conf j-<CLUSTER ID>

from mrjob.job import MRJob


class MRWordFrequencyCount(MRJob):

    def mapper(self, _, line):
        yield "chars", len(line)
        yield "words", len(line.split())
        yield "lines", 1

    def reducer(self, key, values):
        yield key, sum(values)


if __name__ == '__main__':
    MRWordFrequencyCount.run()
