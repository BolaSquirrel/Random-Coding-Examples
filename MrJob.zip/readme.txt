words_alpha.txt taken from
   https://github.com/dwyl/english-words/blob/master/words_alpha.txt,
   last access 11/24/2017

gutenberg.txt is the concatenated text of the following:
   http://www.gutenberg.org/etext/20417,
   http://www.gutenberg.org/etext/5000,
   http://www.gutenberg.org/etext/4300,
   last access 11/24/2017
